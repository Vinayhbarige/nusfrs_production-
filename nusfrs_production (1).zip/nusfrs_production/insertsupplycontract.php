<?php

include "dbconn.php";
include "includes/functions.php";
session_start();
if($_GET['type'] == 'adding'){
    if($_POST['contType'] == 'fixed'){

        $commodityName = '';
        $unit = '';
        foreach($_POST['commodity'] as $value){
             $commodityName =$value;
             if($commodityName == 'natural gas'){
                foreach($_POST['units'] as $values){
                    $unit = $values;
                }
             }
        }
        $contracttype = '';
        $contrindex ='';
        foreach($_POST['contacttype'] as $value){
            $contracttype =$value;
            if($contracttype == 'indexed'){
                $contrindex = $_POST['indexed'];
            }
        }
        $indexstru = '';
        foreach($_POST['indexstr'] as $value){
            $indexstru =$value;
        }
        $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
        $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
        $sql = "INSERT INTO nus_supply_contract (parentId, clientId, commodityName, countryName, commodityUnits, supplyName, contractType, contractIndexId, contractTermfromDate, contractTermtoDate, commodityPrice, totalAnualConsumption, indexStructureType, clickTrancheminsize, consumMinsize, openPrizemechanism, totlconsumption, allmonts, contractpricetype, consumptionmonth,hedgeconsumption) VALUES ('".$_POST['parent']."','".$_POST['client']."', '".$commodityName."','".$_POST['country']."' ,'".$unit."','".$_POST['supplr']."' ,'".$contracttype."', '".$contrindex ."', '".$startDate."', '".$endDate."', '".$_POST['commodityprice']."', '".$_POST['totalanualconsumption']."', '".$indexstru."', '".$_POST['minsizevalue']."', '".$_POST['minsize']."', '".$_POST['openmech']."', '".$_POST['totlcnsumtion']."', '".$_POST['allmonths']."', '".$_POST['contractprice']."', '".$_POST['allmonthsdata']."', '".$_POST['hedge']."')";
        $conn->query($sql);
        $last_id = $conn->insert_id;
        $functions = new libFunc();
        $getserialno = $functions->getlastserialno($_POST['client']);
        $incserialno = $getserialno+1;
        $serialno ='';
        if ( in_array($incserialno, range(1,9)) ) {
            $serialno = '0000'.$incserialno;
        }elseif(in_array($incserialno, range(10,99)) ){
            $serialno = '000'.$incserialno;
        }elseif(in_array($incserialno, range(100,999)) ){
            $serialno = '00'.$incserialno;
        }elseif(in_array($incserialno, range(1000,9999)) ){
            $serialno = '0'.$incserialno;
        }else{
            $serialno = $incserialno;
        }
        $autcm = ($commodityName=='natural gas')?'gas':'elec';
        $getclientname = explode(' ', $_POST['clientname']);
     
        echo $autoId = $getclientname[0].'-'.$autcm.'-'.$serialno;
        $sqls = "UPDATE nus_supply_contract SET contract_id='".$autoId."' WHERE supplierId =".$last_id."";
        $conn->query($sqls);
        $sqlincAutoupdate = "UPDATE clientcompanydata SET serialno='".$incserialno."' WHERE id =".$_POST['client']."";
        $conn->query($sqlincAutoupdate);

    }else{
        $commodityName = '';
        $unit = '';
        foreach($_POST['commodity'] as $value){
             $commodityName =$value;
             if($commodityName == 'natural gas'){
             	foreach($_POST['units'] as $values){
             		$unit = $values;
             	}
             }
        }
        $contracttype = '';
        $contrindex ='';
        foreach($_POST['contacttype'] as $value){
            $contracttype =$value;
            if($contracttype == 'indexed'){
            	$contrindex = $_POST['indexed'];
            }
        }
        $indexstru = '';
        foreach($_POST['indexstr'] as $value){
            $indexstru =$value;
        }
        $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
        $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
        $sql = "INSERT INTO nus_supply_contract (parentId, clientId, commodityName, countryName, commodityUnits, supplyName, contractType, contractIndexId, contractTermfromDate, contractTermtoDate, commodityPrice, totalAnualConsumption, indexStructureType, openPrizemechanism, totlconsumption, allmonts, contractpricetype, consumptionmonth,hedgeconsumption,basegenconsumption,effectcon) VALUES ('".$_POST['parent']."', '".$_POST['client']."', '".$commodityName."','".$_POST['country']."' ,'".$unit."','".$_POST['supplr']."' ,'".$contracttype."', '".$contrindex ."', '".$startDate."', '".$endDate."', '".$_POST['commodityprice']."', '".$_POST['totalanualconsumption']."', '".$indexstru."', '".$_POST['openmech']."', '".$_POST['totlcnsumtion']."', '".$_POST['allmonths']."', '".$_POST['contractprice']."', '".$_POST['allmonthsdata']."', '".$_POST['hedge']."','".$_POST['hedge']."', '".$_POST['hedge']."')";
        $conn->query($sql);
        $last_id = $conn->insert_id;
        $functions = new libFunc();
        $getserialno = $functions->getlastserialno($_POST['client']);
        $incserialno = $getserialno+1;
        $serialno ='';
        if ( in_array($incserialno, range(1,9)) ) {
            $serialno = '0000'.$incserialno;
        }elseif(in_array($incserialno, range(10,99)) ){
            $serialno = '000'.$incserialno;
        }elseif(in_array($incserialno, range(100,999)) ){
            $serialno = '00'.$incserialno;
        }elseif(in_array($incserialno, range(1000,9999)) ){
            $serialno = '0'.$incserialno;
        }else{
            $serialno = $incserialno;
        }
        $autcm = ($commodityName=='natural gas')?'gas':'elec';
        $getclientname = explode(' ', $_POST['clientname']);
        
        $autoId = $getclientname[0].'-'.$autcm.'-'.$serialno;
        $sqls = "UPDATE nus_supply_contract SET contract_id='".$autoId."' WHERE supplierId =".$last_id."";
        $conn->query($sqls);
        $sqlincAutoupdate = "UPDATE clientcompanydata SET serialno='".$incserialno."' WHERE id =".$_POST['client']."";
        $conn->query($sqlincAutoupdate);
        for ($i=1; $i < $_POST['rowcount'] ; $i++) {
        	if(isset($_POST['tradsel'.$i]) && $_POST['tradsel'.$i] != '' ){

                $sql = "INSERT INTO nus_tradeperiods (supplierId, periodsId, clicktracnches, clicktranches) VALUES ('".$last_id."', '".$_POST['tradsel'.$i]."', '".$_POST['tranche'.$i]."', '".$_POST['minsize'.$i]."')";
                $conn->query($sql);
                $last_trade_id = $conn->insert_id;
                $allmonts = explode(',', $_POST['allmonths']);
                $firstdate = array();
                $lastdate = array();
                $yearcount = count($allmonts)/12;
                $yearremaining = count($allmonts)%12;
                $yearrmai = array();
                $year = 1;
                for ($k=0; $k < ($yearcount*12); $k++) { 
                    if($k%12 == 0){
                        $firstdate[] =$allmonts[$k];
                        if($k!=0){
                            $year = $year+1;
                        }
                        
                    }
                    if(((12*$year) - $k) == 1){
                        $lastdate[] = $allmonts[$k];
                    }
                }
                
                if($_POST['tradsel'.$i] == 'Calendar Yearly'){
                    $periodtime =  array();
                    $years = array();
                    for($j=0;$j<count($lastdate);$j++){
                        $periodtime[] = $firstdate[$j].','.$lastdate[$j];
                        $val = explode('-', $lastdate[$j]);
                        $years[] = $val[0];
                    }
                   
                    foreach ($years as $key => $value) {
                        $getindex = array_search($value, $years);
                        $sqlinsert = "INSERT INTO nus_calenderyear (calenderyear, clicks, tradeId, supplierid, timeperiod) VALUES ('".$value."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$periodtime[$getindex]."')";
                        $conn->query($sqlinsert);
                    }

                }
                if($_POST['tradsel'.$i] == 'Calendar Quarterly'){
                    $q1 = ['Jan','Feb','Mar'];
                    $q2 = ['Apr','May','Jun'];
                    $q3 = ['Jul','Aug','Sep'];
                    $q4 = ['Oct','Nov','Dec'];
                   
                        $allmonths = array();
                        $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                        $yearsTrade = array();
                        foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade[] = $monthsexp[0];
                        }
                        $yars = array_unique($yearsTrade);
                        $q1quat = array();
                        $q2quat = array();
                        $q3quat = array(); 
                        $q4quat = array();
                         print_r($yars);
                        foreach ($yars as $key => $yrvalue) {

                           foreach ($allmonths as $key => $mtvalue) {
                                $montva = explode('-', $mtvalue);
                                // print_r($montva);
                                
                                    if(in_array($montva[0], $q1) && $montva[1] == $yrvalue){
                                        array_push($q1quat, $mtvalue);
                                    }

                                    else if(in_array($montva[0], $q2) && $montva[1] == $yrvalue){
                                        
                                             array_push($q2quat, $mtvalue);
                                        
                                        
                                       
                                    }
                                    else if(in_array($montva[0], $q3) && $montva[1] == $yrvalue){
                                        
                                            array_push($q3quat, $mtvalue);
                                        
                                        
                                    }
                                    else if(in_array($montva[0], $q4) && $montva[1] == $yrvalue){
                                        
                                             array_push($q4quat, $mtvalue);
                                        
                                        
                                        
                                    }
                                
                               

                            
                            }
                            
                            if(count($q1quat)!=0){
                                $qtr = 'q1';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q2quat)!=0){

                                $qtr = 'q2';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q3quat)!=0){

                                $qtr = 'q3';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q4quat)!=0){

                                $qtr = 'q4';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            array_splice($q1quat, 0);
                            array_splice($q2quat, 0);
                            array_splice($q3quat, 0);
                            array_splice($q4quat, 0);
                           
                        }
                       
                }
                if($_POST['tradsel'.$i] == 'Calendar Monthly'){
                    $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                    $allmonths = array();
                    $yearsTrade = array();
                    foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade[] = $monthsexp[0];
                    }
                    $yars = array_unique($yearsTrade);
                    foreach ($yars as $key => $yarsvalue) {
                        foreach ($allmonths as $key => $mtvalue) {
                            $montva = explode('-', $mtvalue);
                            if($montva[1]== $yarsvalue){
                                 $sqlinsert = "INSERT INTO nus_calendermonth (month, clicks, TradeId, supplierId, year) VALUES ('".$montva[0]."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$montva[1]."')";
                                $conn->query($sqlinsert);
                            }
                        }
                        
                    }
                }
                if($_POST['tradsel'.$i] == 'Season'){
                    $q1 = ['Oct','Nov','Dec', 'Jan', 'Feb', 'Mar'];
                    $q8 = ['Apr','May','Jun','Jul','Aug','Sep'];
                   
                   
                        $allmonths = array();
                        $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                        $yearsTrade = array();
                        foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade [] = $monthsexp[0];
                            // if(in_array('Mar', $q1)){
                            //     // $yearsTrade[] = $monthsexp[0];
                            //     echo $monthsexp[0];
                            // }
                         

                        }
                        $years = array();
                        foreach ($allmonths as $key => $mtvalue) {
                            $montyear = explode('-', $mtvalue);
                            // echo  $montyear[0];
                            // echo $montyear;
                             
                                if($montyear[0] == 'Jan' && in_array($montyear[1], $yearsTrade)){
                                    // echo 'jo';
                                    $years[] = $montyear[1];
                                   
                                }
                                if($montyear[0] == 'May' && in_array($montyear[1], $yearsTrade)){
                                    $years[] = $montyear[1];

                                    
                                }
                            
                        }
                        
                        $yars = array_unique($years);
                        $q1quat = array();
                        $q2quat = array();
                       
                        print_r($yars);
                        foreach ($yars as $key => $value) {
                           foreach ($allmonths as $key => $mtvalue) {
                                $montva = explode('-', $mtvalue);
                                // print_r($montva);
                                
                                    if(in_array($montva[0], $q1) && $value == $montva[1]){
                                        array_push($q1quat, $mtvalue);
                                    }

                                    else if(in_array($montva[0], $q8) && $value == $montva[1]){
                                        
                                             array_push($q2quat, $mtvalue);
                                        
                                    }
                                   
                            }

                            if(count($q1quat)!=0){
                                $qtr = 'oct-mar';
                                $sqlinsert = "INSERT INTO nus_season (season, clicks, tradeId, supplierId, yeartrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$value."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q2quat)!=0){
                                $qtr = 'apr-sep';
                                $sqlinsert = "INSERT INTO nus_season (season, clicks, tradeId, supplierId, yeartrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$last_id."', '".$value."')";
                                $conn->query($sqlinsert);
                            }
                            print_r($q1quat);
                            print_r($q2quat);
                            array_splice($q1quat, 0);
                            array_splice($q2quat, 0);
                    }
                           
                        
                }
                
        		
        	}
        }
    }
    $_SESSION['created'] = time();
    header("location:addsupplycontract.php");
}else{
    echo $_POST['totalanualconsumption'];
    $commodityName = '';
    $unit = '';
    foreach($_POST['commodity'] as $value){
         $commodityName =$value;
         if($commodityName == 'natural gas'){
            foreach($_POST['units'] as $values){
                $unit = $values;
            }
         }
    }
    $contracttype = '';
    $contrindex ='';
    foreach($_POST['contacttype'] as $value){
        $contracttype =$value;
        if($contracttype == 'indexed'){
            $contrindex = $_POST['indexed'];
        }
    }
    $indexstru = '';
    foreach($_POST['indexstr'] as $value){
        $indexstru =$value;
    }
    $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
    $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
    $sqlupdate = "UPDATE nus_supply_contract SET parentId='".$_POST['parent']."',clientId='".$_POST['client']."', commodityName='".$commodityName."', countryName='".$_POST['country']."', commodityUnits='".$unit."', supplyName='".$_POST['supplr']."', contractType='".$contracttype."', contractIndexId='".$contrindex ."', contractTermfromDate='".$startDate."', contractTermtoDate='".$endDate."', commodityPrice='".$_POST['commodityprice']."', totalAnualConsumption='".$_POST['totalanualconsumption']."', indexStructureType='".$indexstru."',  openPrizemechanism='".$_POST['openmech']."',totlconsumption='".$_POST['totlcnsumtion']."',allmonts='".$_POST['allmonths']."', contractpricetype='".$_POST['contractprice']."',hedgeconsumption='".$_POST['hedge']."',consumptionmonth='".$_POST['allmonthsdata']."' WHERE supplierId = ".$_GET['id']."";
    $conn->query($sqlupdate);
    if($contracttype !='fixed'){
        $delsql = "DELETE FROM nus_tradeperiods WHERE supplierId=".$_GET['id']."";
        $conn->query($delsql);
        $calsql = "DELETE FROM nus_calenderyear WHERE supplierid=".$_GET['id']."";
        $conn->query($calsql);
        $quartsql = "DELETE FROM nus_calenderquarter WHERE supplierid=".$_GET['id']."";
        $conn->query($quartsql);
        $mnthsql = "DELETE FROM nus_calendermonth WHERE supplierId=".$_GET['id']."";
        $conn->query($mnthsql);
        $seasonsql = "DELETE FROM nus_season WHERE supplierId=".$_GET['id']."";
        $conn->query($seasonsql);
        for ($i=0; $i < $_POST['rowcount'] ; $i++) {
            if(isset($_POST['tradsel'.$i]) && $_POST['tradsel'.$i] != '' ){
                $sql = "INSERT INTO nus_tradeperiods (supplierId, periodsId, clicktracnches, clicktranches) VALUES ('".$_GET['id']."', '".$_POST['tradsel'.$i]."', '".$_POST['tranche'.$i]."', '".$_POST['minsize'.$i]."')";
                $conn->query($sql);
                $last_trade_id = $conn->insert_id;
                $allmonts = explode(',', $_POST['allmonths']);
                $firstdate = array();
                $lastdate = array();
                $yearcount = count($allmonts)/12;
                $yearremaining = count($allmonts)%12;
                $yearrmai = array();
                $year = 1;
                for ($k=0; $k < ($yearcount*12); $k++) { 
                    if($k%12 == 0){
                        $firstdate[] =$allmonts[$k];
                        if($k!=0){
                            $year = $year+1;
                        }
                        
                    }
                    if(((12*$year) - $k) == 1){
                        $lastdate[] = $allmonts[$k];
                    }
                }
                
                if($_POST['tradsel'.$i] == 'Calendar Yearly'){
                    $periodtime =  array();
                    $years = array();
                    for($j=0;$j<count($lastdate);$j++){
                        $periodtime[] = $firstdate[$j].','.$lastdate[$j];
                        $val = explode('-', $lastdate[$j]);
                        $years[] = $val[0];
                    }
                   
                    foreach ($years as $key => $value) {
                        $getindex = array_search($value, $years);
                        $sqlinsert = "INSERT INTO nus_calenderyear (calenderyear, clicks, tradeId, supplierid, timeperiod) VALUES ('".$value."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$periodtime[$getindex]."')";
                        $conn->query($sqlinsert);
                    }

                }
                if($_POST['tradsel'.$i] == 'Calendar Quarterly'){
                    $q1 = ['Jan','Feb','Mar'];
                    $q2 = ['Apr','May','Jun'];
                    $q3 = ['Jul','Aug','Sep'];
                    $q4 = ['Oct','Nov','Dec'];
                   
                        $allmonths = array();
                        $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                        $yearsTrade = array();
                        foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade[] = $monthsexp[0];
                        }
                        $yars = array_unique($yearsTrade);
                        $q1quat = array();
                        $q2quat = array();
                        $q3quat = array(); 
                        $q4quat = array();
                         print_r($yars);
                        foreach ($yars as $key => $yrvalue) {

                           foreach ($allmonths as $key => $mtvalue) {
                                $montva = explode('-', $mtvalue);
                                // print_r($montva);
                                
                                    if(in_array($montva[0], $q1) && $montva[1] == $yrvalue){
                                        array_push($q1quat, $mtvalue);
                                    }

                                    else if(in_array($montva[0], $q2) && $montva[1] == $yrvalue){
                                        
                                             array_push($q2quat, $mtvalue);
                                        
                                        
                                       
                                    }
                                    else if(in_array($montva[0], $q3) && $montva[1] == $yrvalue){
                                        
                                            array_push($q3quat, $mtvalue);
                                        
                                        
                                    }
                                    else if(in_array($montva[0], $q4) && $montva[1] == $yrvalue){
                                        
                                             array_push($q4quat, $mtvalue);
                                        
                                        
                                        
                                    }
                                
                               

                            
                            }
                            
                            if(count($q1quat)!=0){
                                $qtr = 'q1';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q2quat)!=0){

                                $qtr = 'q2';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q3quat)!=0){

                                $qtr = 'q3';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q4quat)!=0){

                                $qtr = 'q4';
                                $sqlinsert = "INSERT INTO nus_calenderquarter (quarters, clicks, tradeid, supplierid, yearoftrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$yrvalue."')";
                                $conn->query($sqlinsert);
                            }
                            array_splice($q1quat, 0);
                            array_splice($q2quat, 0);
                            array_splice($q3quat, 0);
                            array_splice($q4quat, 0);
                           
                        }
                       
                }
                if($_POST['tradsel'.$i] == 'Calendar Monthly'){
                    $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                    $allmonths = array();
                    $yearsTrade = array();
                    foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade[] = $monthsexp[0];
                    }
                    $yars = array_unique($yearsTrade);
                    foreach ($yars as $key => $yarsvalue) {
                        foreach ($allmonths as $key => $mtvalue) {
                            $montva = explode('-', $mtvalue);
                            if($montva[1]== $yarsvalue){
                                 $sqlinsert = "INSERT INTO nus_calendermonth (month, clicks, TradeId, supplierId, year) VALUES ('".$montva[0]."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$montva[1]."')";
                                $conn->query($sqlinsert);
                            }
                        }
                        
                    }
                }
                if($_POST['tradsel'.$i] == 'Season'){
                    $q1 = ['Oct','Nov','Dec', 'Jan', 'Feb', 'Mar'];
                    $q8 = ['Apr','May','Jun','Jul','Aug','Sep'];
                   
                   
                        $allmonths = array();
                        $months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
                        $yearsTrade = array();
                        foreach ($allmonts as $key => $values) {
                            $monthsexp = explode('-', $values);
                            $allmonths[] = $months[$monthsexp[1]-1].'-'.$monthsexp[0];
                            $yearsTrade [] = $monthsexp[0];
                            // if(in_array('Mar', $q1)){
                            //     // $yearsTrade[] = $monthsexp[0];
                            //     echo $monthsexp[0];
                            // }
                         

                        }
                        $years = array();
                        foreach ($allmonths as $key => $mtvalue) {
                            $montyear = explode('-', $mtvalue);
                            // echo  $montyear[0];
                            // echo $montyear;
                             
                                if($montyear[0] == 'Jan' && in_array($montyear[1], $yearsTrade)){
                                    // echo 'jo';
                                    $years[] = $montyear[1];
                                   
                                }
                                if($montyear[0] == 'May' && in_array($montyear[1], $yearsTrade)){
                                    $years[] = $montyear[1];

                                    
                                }
                            
                        }
                        
                        $yars = array_unique($years);
                        $q1quat = array();
                        $q2quat = array();
                       
                        print_r($yars);
                        foreach ($yars as $key => $value) {
                           foreach ($allmonths as $key => $mtvalue) {
                                $montva = explode('-', $mtvalue);
                                // print_r($montva);
                                
                                    if(in_array($montva[0], $q1) && $value == $montva[1]){
                                        array_push($q1quat, $mtvalue);
                                    }

                                    else if(in_array($montva[0], $q8) && $value == $montva[1]){
                                        
                                             array_push($q2quat, $mtvalue);
                                        
                                    }
                                   
                            }

                            if(count($q1quat)!=0){
                                $qtr = 'oct-mar';
                                $sqlinsert = "INSERT INTO nus_season (season, clicks, tradeId, supplierId, yeartrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$value."')";
                                $conn->query($sqlinsert);
                            }
                            if(count($q2quat)!=0){
                                $qtr = 'apr-sep';
                                $sqlinsert = "INSERT INTO nus_season (season, clicks, tradeId, supplierId, yeartrade) VALUES ('".$qtr."',  '".$_POST['tranche'.$i]."', '".$last_trade_id."', '".$_GET['id']."', '".$value."')";
                                $conn->query($sqlinsert);
                            }
                            print_r($q1quat);
                            print_r($q2quat);
                            array_splice($q1quat, 0);
                            array_splice($q2quat, 0);
                    }
                           
                        
                }
            }
        }
    }
    

    
    $_SESSION['updated'] = time();
    header("location:supplycontractpreview.php?id=".$_GET['id']."&type=edit");
}

