<?php include 'dbconn.php'?>
<?php
session_start();
	 $sql = "INSERT INTO clientcompanydata (parentcompany, clientcompany, country) VALUES ('".$_POST['parentcompany']."', '".$_POST['clientcompany']."','".$_POST['country']."')";
     $conn->query($sql);
     $_SESSION['createdclient'] = time();
     header('location:addcompany.php');
?>