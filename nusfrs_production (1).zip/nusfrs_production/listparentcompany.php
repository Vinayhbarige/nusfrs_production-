
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System | Parent Company List</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link
      rel="stylesheet"
      href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"
    />
    <style>

        #DataTables_Table_0_wrapper {
            position: absolute;
            width: 87%;
            margin: 80px 0 0 360px;
        }

       #myTable_wrapper {
            position: absolute;
            width: 76%;
            margin: 0px 0 0 300px;
        }

      
        table {
            border: 2px solid #CED4DA;
            border-radius: 6px;
            width: 76%;
            margin: 10px 300px;
            /* height: 70vh; */
        }
        /* table.dataTable thead > tr > th.sorting_asc::before {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        }
        table.dataTable thead > tr > th.sorting::after {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        } */
        table th {
            color: #343a40;
            background: #F9FBFD;
        }
        table.myTable thead th {
	        border-bottom: 1px solid #CED4DA !important;
        }
        table td {
            color: #12263F;
            font-size: 13px;
            border-bottom: 1px solid #CED4DA;
        }
        table.dataTable.no-footer {
            /* border-bottom: 2px solid #D2DDEC !important; */
            border-bottom: none !important;
        }

        table tbody td a {
            color: #345DA6;
            font-size:14px;
        }
        .parentdatas{
            text-decoration: none;
        }
        .parent {
            text-align:left;
        }
        .views{
            color: #fff;
           
            padding:5px 10px;
            border-radius:25px;
        }
        table.dataTable thead > tr > th.sorting_asc::before, 
        table.dataTable thead > tr > th.sorting_desc::after {
            opacity: 1;
        }
        td {
            background: white;
        }
        .viewclient {
            color: #fff;
            padding:5px 10px;
            border-radius:25px;
        }
        .viewIcon {
            width: 24px;
            height:24px;
            /* background-color: #345DA6; */
        }
    </style>
</head>
<body>

<table class="myTable" id ="myTable" >
		<thead class="tableheadings">
			
			<th class="parent">Parent Company</th>
            <th class="parent">Clients</th>
            <th class="parent"></th>
			
		</thead>
		<tbody>
        <?php
            include('dbconn.php');
            include 'includes/functions.php';
            $functions = new libFunc();
            $wherefiled = '';


            if($_SESSION['role'] == 'Parent company') {
                $wherefiled = "AND parentcompany ='".$_SESSION['parent']."'";
                // echo 'Im Parent';
            }
            if($_SESSION['role'] == 'Client company') {
                $wherefiled = "AND parentcompany ='".$_SESSION['parent']."'";
                // echo 'Im Client';
            }
            // echo $wherefiled;
            $sql = "SELECT * FROM parentcompanydata WHERE 1 ".$wherefiled."";
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                
            <td><a href="clientcompany.php?id=<?php echo $row['parentcompany'] ?>"><?php echo $row['parentcompany'];?></a></td>
            <td><?=$functions->getcountclient($row['parentcompany'])?></td>
            <td><a  class="views" href="clientcompany.php?id=<?php echo $row['parentcompany'] ?>"><img src="img/views3.svg" alt="" class ="viewIcon"></a></td>
            </tr>
            <?php
            }
            ?>
           
		</tbody>
	</table>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
    </script>
    <script>
        $(document).ready( function () {
         $('#myTable').DataTable();
        } );
    </script>
     <?php
        include('hoverinclude/hoverhome.php');
    ?>
    </body>
</html>
