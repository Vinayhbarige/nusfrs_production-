<?php

$sername = "localhost";
$user = "i2253940_wp1";
$pass = "QualesceMas1";
$dbname = "i2253940_wp1";

$conn = mysqli_connect($sername, $user, $pass, $dbname);

if(!$conn) {
    echo "Connection Failed...!";
}

?>